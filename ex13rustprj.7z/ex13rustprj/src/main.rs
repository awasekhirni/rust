use std::collections::HashSet;


fn main() {
    println!("Rust Programming - HashSet Programming- Syed Awase 2017");
     let mut cities=HashSet::new(); 
     cities.insert("ajmer");
     cities.insert("delhi");
     cities.insert("gulbarga");
     cities.insert("hyderabad");
     cities.insert("aurangabad");
     cities.insert("lucknow");
     cities.insert("mursheedabad");
     println!("hashset display list of cities:{:?}",cities);

     //compute the length of the hashset 
     println!("size of the set:{:?}",cities.len());

     //for each loop 
     for city in cities.iter(){
         println!("city has a name:{}",city);
     }

     //match operation 
     match cities.get(&"aurangabad"){
         Some(value)=>{
             println!("have found the match!:{}",value);
         }
         None=>{
             println!("Not a perfect match!");
         }
     }

    // contains check 
    if cities.contains(&"delhi"){
        println!("we have found a successful match!");
    }

    //removing a value from the hash set 
    cities.remove(&"mursheedabad");
    println!("post removal hash set is {:?}", cities);

}
