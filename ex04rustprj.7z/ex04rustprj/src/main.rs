mod othermodule;
// use the file name to import module 

fn main() {
    println!("Rust Programming - Modules Demo- 2017 Syed Awase");
   othermodule::display_msg();
   let msg=othermodule::call_privatefn();
 println!("{}",msg);

}
