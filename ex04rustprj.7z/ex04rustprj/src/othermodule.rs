
pub fn display_msg(){
    println!("Calling a function from othermodule file, file name is used as module");
    
}

pub fn call_privatefn()->String{
    return lost_in_translation();
}

fn speak_german(){
    println!("Do you speak german!");
}

fn speak_arabic(){
    println!("Do you speak arabic!");
}

fn speak_french(){
    println!("Do you speak french!");
}

fn speak_urdu(){
    println!("Do you speak urdu!");
}


pub fn lost_in_translation()->String{
    speak_german();
    speak_french();
    speak_urdu();
    speak_arabic();
    return String ::from(" Urdu:Mujhe samajh mein nahin aa raha hain!
             German:ich verstehe nicht
             Arabic:la'afham
             French:Je ne comprends pas");


}