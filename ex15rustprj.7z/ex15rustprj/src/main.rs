fn main() {
    println!("Rust Programming -Tuples -Syed Awase 2017 ");
    let intuple:(i32,f64,u8)=(-312,6.626070,91);
    println!("integer is :{:?}",intuple.0);
    println!("float is :{:?}",intuple.1);
    println!("unsigned integer is:{:?}",intuple.2);

    let b:(i32,bool,f64)=(1326,true,3.1456);
    println!("{:?}",b);

    let samsung:(i32,bool,f64)=(560,true,25.50);
    display_tupleinfo(samsung);
}

//destructuring the tuple
fn display_tupleinfo(z:(i32,bool,f64)){
    let (price,is_active,discount)=z;
    println!("pricepoint:{}, is_active_check:{},discount:{}",price,is_active,discount);
}
