/*
 *   Copyright (c) 2018
 *   All rights reserved.
 */

 pub fn play(name:String){
     println!("Hindi Movies playing {}:movies-app", name);
 }