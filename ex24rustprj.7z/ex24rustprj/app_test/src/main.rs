/*
 *   Copyright (c) 2018
 *   All rights reserved.
 */
extern crate app_lib;
use app_lib::movies::play;

fn main() {
    println!("Ex24- modules and crates in rust language - Syed Awase Khirni");
    println!("Application testing done using the movies");
    play("QuickGunMurugan".to_string());
}
