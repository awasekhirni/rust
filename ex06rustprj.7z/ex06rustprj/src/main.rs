
struct Employee{
    name:String,
    company:String,
    age:u32
}

struct TempEmployee{
    name:String,
    company:String, 
    age:u32
}

fn display_info(emp:Employee){
    println!("Name is:{}, company is{}, age is{}",emp.name, emp.company,emp.age);
}

fn main() {
    println!("Rust Programming-Structures Custom Data Types - Syed Awase 2017");

    let aicy=Employee{
        name:String::from("Syed Awase Khirni"),
        company:String::from("SycliQ Geospatial Pvt Ltd"),
        age:38

    };

    println!("The Employee Records are{},{},{}", aicy.name,aicy.company,aicy.age);


    let mut abu=TempEmployee{
        company:String::from("Abu Raja"),
        name:String::from("TPRI"),
        age:23
    };
 
    abu.company=String::from("CXI");
 
    println!("the temp employee records are {},{},{}",abu.name,abu.company,abu.age);

    display_info(aicy);

}


