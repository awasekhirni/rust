


fn main() {
    println!("Rust Programming - Arrays and Vectors -Syed Awase 2017");
 
    let mut arr_val:[i32;5]=[23,34,45,67,76];
    println!("arr_val has {} elements,length is {}",arr_val[3],arr_val.len());

    let j=[1;10];
    for i in 0..j.len(){
        println!("{}",j[i]);
    }

    //multidimensional element 
    let mdx:[[f32;3];2]=[
        [1.34,1.54,1.45],
        [0.36,2.16,2.26]
    ];
    println!("{:?}",mdx);

for x in 0..mdx.len(){
    for y in 0..mdx[x].len(){
        if x==y{
            println!("mdx[{}][{}]={}", x, y, mdx[x][y]);
        }
    }
}

}
