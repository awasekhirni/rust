#![allow(dead_code)]
#![allow(unused_variables)]
#![allow(unused_imports)]


#[derive(Default)]
pub struct Product{
    color:i32,
    weight:f64,
    price:f64,
    is_onsale:bool,
    name:String,
    _secret:(),
}

impl Product{
  
    //getter
    pub fn get_color(&self)-> &i32{
        &self.color
    }


    //setter
   pub fn set_color(&mut self)->&mut i32{
        &mut self.color
    }

//getter
   pub fn get_weight(&self)->&f64{
        &self.weight
    }
//setter
   pub fn set_weight(&mut self)->&mut f64{
        &mut self.weight
    }

   pub fn get_price(&self)->&f64{
        &self.price
    }

   pub fn set_price(&mut self)->&mut f64{
        &mut self.price
    }


   pub fn get_is_onsale(&self) ->&bool{
        &self.is_onsale
    }


   pub fn set_is_onsale(&mut self)->&mut bool{
        &mut self.is_onsale
    }


   pub fn get_name(&self)->&String{
        &self.name
    }

    pub fn set_name(&mut self)-> &mut String{
        &mut self.name
    }


    //constructor 
    pub fn new(color:i32,weight:f64,price:f64,is_onsale:bool, name:String)->Product{
        Product{
            color:color,
            weight:weight,
            price:price,
            is_onsale:is_onsale,
            name:name,
            _secret:()
        }
    }


}


// //destroyer 
// impl Drop for Product{
//     fn drop(&mut self){

//     }
// }