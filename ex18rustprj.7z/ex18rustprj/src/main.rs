#![allow(dead_code)]
#![allow(unused_variables)]
#![allow(unused_imports)]

mod product;
mod person;


fn main() {
    println!("Rust Programming - Object Oriented Programming -Syed Awase 2017");
   
    let mut my_person=person::Person::default();
    *my_person.set_first_name_mut()=String::from("Awase Khirni");
    *my_person.set_last_name_mut()="Syed".into();

    println!("first_name:{}",my_person.get_first_name());
    println!("last_name:{}",my_person.get_last_name());


    //constructors for product 
    let mut samsung=product::Product::new(1256,23.43,560.50,true, String::from("Samsung S7"));

    let mut apple=product::Product::new(2138,43.21,840.50,true,String::from("Apple i7"));
    println!("{}",samsung.get_name());
    println!("{}",apple.get_name());


    //calling the closure function here 
    closure_function();


}


fn closure_function(){
    //adding the reference to the outer_function
    let myreffunction = outer_function;
//calling the outerfunction
    myreffunction();


    let scoped_to_closure= |count:i32|->i32{count *7};
    let count =12;
    println!("count:{}, scoped_to_closure value:{}",count,scoped_to_closure(count));
}


fn outer_function(){
    println!("This is an outer function available every where, you call it!");
}