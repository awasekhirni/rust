#![allow(dead_code)]
#![allow(unused_variables)]
#![allow(unused_imports)]

#[derive(Default)]
pub struct Person{
    first_name:String,
    last_name:String,
}


impl Person{

    //Immutable access
   pub fn get_first_name(&self)->&String{
        &self.first_name
    }

   pub fn get_last_name(&self)->&String{
        &self.last_name
    }

    //mutable access 
   pub fn set_first_name_mut(&mut self)->&mut String{
        &mut self.first_name
    }

    pub fn set_last_name_mut(&mut self)->&mut String{
        &mut self.last_name
    }



}