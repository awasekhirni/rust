use std::mem;


fn main() {
    println!("Rust Programming- Vectors(Dynamic Array)-Syed Awase 2017");
    //initializing a vector 
    // vector is by default mutable 
    let mut victorinox= Vec::new(); 
    victorinox.push(123213);
    victorinox.push(366232);
    victorinox.push(326382);
    victorinox.push(327423);

    victorinox[1]=63276;

    println!("victorinox values={:?}",victorinox);
    println!("printing value at an index:{}",victorinox[2]);
    

    let mut bictor:Vec<i32>=vec![6523,34788,983498,3993,367723,88923];
    //fetching the single value 
    println!("Single value of bictor:{}",bictor[1]);
    println!("fetching the length of bictor:{}",bictor.len());
    //Get Slice 
    let slice: &[i32]=&bictor[1..3];
    println!("Slicing:{:?}",slice);
    //get the size 
    println!("Vector occupies {} bytes",mem::size_of_val(&bictor));
  //adding a item 
  bictor.push(36512);
  //getting the last value or remove the elemnt
  let last_elem=bictor.pop();
  println!("the last element:{:?}",last_elem);
  
  for i in bictor.iter(){
      println!("Numbers in bictor are {}",i);
  }

  //loop and mutate values 
  for x in bictor.iter_mut(){
      *x/=2;
  }
  println!("Numbers in bictor are:{:?}",bictor);

  //matching values 
  match bictor.get(2){
      Some(x)=>println!("bictor[2]={}",x),
      None=>println!("Error, no such element exists")
  }


  //printing all the elements in reverse order 
  while let Some(x)=bictor.pop(){
      println!("reverse order printing of elements:{}",x);
  }

  //removing and returning the element at the position index within the vector
  let mut movie_rank=vec![123,245,534,32,77,82];
  movie_rank.remove(2);
  println!("printing the list of hollywood movies:{:?}",movie_rank);

 //checking if an element exists in the vector 
 
 if movie_rank.contains(&77){
     println!("Found 77");
 }



}
