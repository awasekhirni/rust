fn main() {
    println!("Rust Programming -Pattern Matching -Syed Awase 2017");
    connection_nodes();

}


fn dbconnection_load(connection:i32)-> &'static str{
    match connection{
        0=>"No Connections to the MySQL database exist",
        _ if (connection >=50 && connection <=90) => "the number of connections has exceeded 50% pool and the connections are {}",
        threshold @ 90...99=> "You just have a very few connections left in the pool",
        _ =>"there are {} connections to the MySQL database"
    }
}

pub fn connection_nodes(){
    for connection in 0..100{
        println!("We have {} connections to the database,{}",connection,dbconnection_load(connection));
    }
}
