


fn main() {
    println!("Rust Control Structures Demo - Syed Awase 2017");
    let outside_temp=40;
    if outside_temp>29{
        println!("It is very hot in Bangalore, this summer!");
        println!("In 1997, the temperature was around 29-30");
        println!("outsideTemp is {}",outside_temp);
        println!("put the AC at 18c")
    } else if outside_temp<14{
        println!("it is pleasant weather in the mornings in bangalore!");
        println!("turn off the ac, electricity per unit is Rs.6.30");
    }
    else {
        println!("Temperature is pleasant for a jog in cubbon park!");
    }


    let climate = if outside_temp <10{"cold"} else if outside_temp <28 {"pleasant"} else{"HOT!"};

    println!("the bangalore climate is {}",climate);



    //nested if statements 
    let stock_price =43.65;

    if stock_price >50.00{
        if stock_price> 60.00{"it has increased by 20% "} else {" it is still below 20% threshold increase"}
    }else{
        "it has decreased by 20%"
    };


println!("stockprice is{}",stock_price);


let mut bse_stock_sold=20;
while bse_stock_sold <20000{
    bse_stock_sold *= 20;
    if bse_stock_sold ==10000{
        continue;
    }
    println!("no of shares sold are:{}", bse_stock_sold);
}

//while true condition 

//loop infinite looping 

let mut z=2;

loop{
    z *=3;
    println!("z={}",z);
    if z >=8000 {break;}
}


//for loop in rust programming 
//it is a bit different unlike in other programming languages 
//stopping value is 101
for i in 90..101{
println!("value of i is {}", i)
}

//extracting the index of the iteration in the for loop 
for (pos, j) in (990..1001).enumerate(){
    println!("index is{}: values is{}",pos,j);
}


//match statement in rust programming 

let lang_code="ar";

let spoken_lang= match lang_code
{
    "ab"=> "Abkhaz",
    "ar"=>"Arabic",
    "da"=>"Danish",
    "nl"=>"Dutch",
    "de"=>"German",
    "en"=>"English",
    _=>"Unknown"
};
println!("this language was spoken by {}:{}",lang_code, spoken_lang);





}