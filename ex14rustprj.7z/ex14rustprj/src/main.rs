fn main() {
    println!("Rust Programming Example- STRINGS Syed Awase 2017");
    //utf-8 character set
    let mysong : &'static str= "You know hello! You fool i love you! Come on enjoy the joy ride!"; 
    for c in mysong.chars(){
        println!("characters in the string:{}",c);
    }

    //printing the string in reverse order 
    for c in mysong.chars().rev(){
        println!("characters in the reverse order are:{}",c);
    }

    if let Some(first_char)=mysong.chars().nth(0){
        println!("the first letter is:{}",first_char);
    }

    //String Constructor in Rust language. 
    // heap allocated construct 
    // UTF-8 character set 
    let mut myletters = String::new(); 
    //printing a sequence of letters from a to z 
    let mut a='a' as u8;
    while a<= ('z' as u8){
        myletters.push(a as char);
        myletters.push_str(",");
        a+=1;
    }

    println!("{}",myletters);

    let mut gala ="betty bought a bit of butter".to_string();
    gala.remove(2);
    gala.push_str("ugly");
    println!("{}",gala.replace("bety","bubbly"));
    println!("{}",gala);

    



}
