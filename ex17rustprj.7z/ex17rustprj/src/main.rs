//use std::fmt::Display;
use std::ops::Mul;

fn main() {
    println!("Rust Programming - Generics Demo- Syed Awase 2017");
    // let coord_start:Point = Point{gps_x:74.2, gps_y:73.43};
    // let coord_end:Point=Point{gps_x:123.12,gps_y:167.28};
    // println!("{},{}",coord_start, coord_end);

    // let sline=Polyline{coord_start,coord_end};
    // println("{?}",sline);
   let result =square(5);
   println!("Result={:?}",result);

}

fn square<T: Mul<Output = T> + Copy> (x: T) -> T {

    return x * x;
}
// //generic 
// struct Point<T>{
//     gps_x:T,
//     gps_y:T
// }


// struct Polyline<T>{
//     start:Point<T>,
//     end:Point<T>
// }



