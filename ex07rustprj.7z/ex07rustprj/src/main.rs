
struct Rectangle{
    width:u32, height:u32
}

//computing the area of the rectange 
impl Rectangle{
    fn compute_area(&self) ->u32{
        self.width*self.height
    }

    fn compute_perimeter(&self)->u32{
        2*self.width*self.height
    }

   //creating a static methods  that create object of employee
   fn get_instance(width:u32,height:u32)->Rectangle{
       Rectangle{width:width,height:height}
   }


   //display values of the structure field 
   fn display(&self){
       println!("width of the rectangle:{}, height of the rectangle: {}",self.width,self.height);
   }

}




fn main() {
    println!("Rust Programming - Structures and Implementation methods Demo - Syed Awase 2017");

    let bx=Rectangle{
        width:24,
        height:38

    };

    //println the rectangle area and perimeter 
    println!("area is {}, perimeter is {}",bx.compute_area(), bx.compute_perimeter());
    bx.display();
}
