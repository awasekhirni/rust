use std::collections::HashMap;

fn main() {
    println!("Rust Programming - HashMap Collections - Syed Awase 2017");
    let mut lang_codes = HashMap::new();
    lang_codes.insert("en","English");
    lang_codes.insert("ar","Arabic");
    lang_codes.insert("cn","Chineese");
    lang_codes.insert("de","Deutsch");
    lang_codes.insert("fr","French");
    lang_codes.insert("fs","Farsi");
    lang_codes.insert("hn","Hindi");
    println!("print the list of codes:{:?}",lang_codes);


    //print the length of the hashmap 
    println!("print the length of hashmap:{:?}",lang_codes.len());

    //matching values in hashmap
    match lang_codes.get(&"ar"){
        Some(value)=>{
            println!("Value for key ar is {}",value);
        }
        None=>{
            println!("We could not find the match!");
        }
    }


    //iteration 
    for (key,val) in lang_codes.iter(){
        println!("Key:{}- val:{}",key,val);
    }


    //check whether a key exists 
    if lang_codes.contains_key(&"ar"){
        println!("we have successfully found the key!");
    }


    //remove the element 
    lang_codes.remove(&"hn");
    println!("the elements of hashmap post remove operation are:{:?}", lang_codes);
    

}
