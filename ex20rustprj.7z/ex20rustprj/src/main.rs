macro_rules! hello{
    ()=>{
        println!("Hello! Syed Awase-You are Using Macros");
    }
}

macro_rules! myprint{
    ($i:ident,$e:expr)=>{
        let $i={
            let a=$e;
            println!("{}",a);
            a
        };
    }
}

macro_rules! four{
    ()=>{1+3};
}

macro_rules! times_ten{
    ($e:expr)=>{10*$e};
}

macro_rules! multiply_add{
    ($a:expr,$b:expr,$c:expr)=>{
        $a*($b+$c)
    };
}


macro_rules! vec_strs {
    (
        // Start a repetition:
        $(
            // Each repeat must contain an expression...
            $element:expr
        )
        // ...separated by commas...
        ,
        // ...zero or more times.
        *
    ) => {
        // Enclose the expansion in a block so that we can use
        // multiple statements.
        {
            let mut v = Vec::new();

            // Start a repetition:
            $(
                // Each repeat will contain the following statement, with
                // $element replaced with the corresponding expression.
                v.push(format!("{}", $element));
            )*

            v
        }
    };
}


macro_rules! using_a{
    ($a:ident,$e:expr)=>{
        {
            let $a=42;
            $e
        }
    }
}






fn main() {
    println!("Rust Programming - Macros! Demo - Syed Awase 2017");

    //calling the hello macro
    hello!();

    //calling the myprint macro 
    myprint!(x,48+12);
    println!("another macro for expression:{}",x);
    
    //four macro demo 
    println!("{}",four!());


    //times 10 
    println!("{}",times_ten!(10));

let four = using_a!(a,a/10);


}
