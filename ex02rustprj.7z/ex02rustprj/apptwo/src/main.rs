//Copyright Syed Awase Khirni 2016-17 www.sycliq.com www.territorialprescience.com 

//importing an external library to compute the size of the variable

use std::mem;


fn main() {
    println!("Rust Data Type Demo -Syed Awase");
    //rust variable binding are IMMUTABLE by default 
    //binding the variable to a memory location 
    //unsigned number 0 to 255
    let x:u8=253;
    // integer number -127 to 127
    let score:i8=99;

    //printline macro
    println!("x={}",x);
    println!("score={}",score);

    //mutable variable declaration 
    //"mut" keyword // i8 => indicate signed integer with 8 bits
    let mut y:i8=26;
    //printline macro
    println!("y={}", y);
    y=89;
    //changing the value of the variable y
    println!("y={}",y);

    //creating a 32 bit signed integer 
    let mut capacity=123812398;
    //println macro to print the size of guid
    println!("capacity={},size={} bytes",capacity,mem::size_of_val(&capacity));
    capacity=761276213;
    println!("capacity={}",capacity);

    //i8 u8 signed and unsigned integer 8bytes 
    //i16 u16 signed and unsigned integer 16bytes 
    //u32 i32  signed and unsigned integer  32 bytes 
    //i64 u64 signed and unsigned integer => 64

    //
    let z:isize = 56132;
    let size_of_z=mem::size_of_val(&z);
    println!("z={}, takes up {} bytes, {}-bit OS", z, size_of_z,size_of_z*8);
    //get the size of the char
     let d='m';
     println!("d={},size={}bytes", d, mem::size_of_val(&d));

     //computing the size of a string 
     let name="Syed Awase Khirni";
     println!("name={}, size={} bytes", name, mem::size_of_val(&name));

     let mysong="You know hello! you fool i love you, comeon enjoy the joyride!";
     println!("mysong={},size={} bytes", mysong, mem::size_of_val(&mysong));


     //floating point numbers 
    //double precision IEEE754r conformance 
    //https://en.wikipedia.org/wiki/IEEE_754-2008
    let pi:f32=3.1456; 
    println!("pi={}, size of pi={} bytes", pi,mem::size_of_val(&pi));

 //boolean data types in rust programming 
 let accept=false;
 println!("accept={}, size={} bytes", accept, mem::size_of_val(&accept));



}
