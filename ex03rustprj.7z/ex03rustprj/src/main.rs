

//global variables 
const PLANCK:f64=6.62607015;
//static 
static dburl:&str ="localhost:5432/postgres:dbp@ssw0rd";

fn main() {
    println!("ex03rustprogramming -Syed Awase Khirni");
    //arithmetic operations in rust 
    let mut x=2123*323+1234/22;
    println!("{}",x);
    //increment and decrement operations 
    x +=10;
    x -=20;
    x /=3;

    println!("{}",x);
    println!("reminder of {}/{}={}",x,7,(x%7));

    //computing cube of a number 
    let y_cube=i32::pow(8,3);
    println!("{} cubed is {}", x,y_cube);

    let val=3.1456;
    let val_cube=f64::powi(val,4);

    println!("{} integer power is{}",val,val_cube);


   let pascally=2.6;
   let pascally_pi=f64::powf(pascally,std::f64::consts::PI);
   println!("{} float power is{} ", pascally, pascally_pi);


//bitwise operations are available for integers only in rust 
// Bitwise operations
    println!("0011 AND 0101 is {:04b}", 0b0011u32 & 0b0101);
    println!("0011 OR 0101 is {:04b}", 0b0011u32 | 0b0101);
    println!("0011 XOR 0101 is {:04b}", 0b0011u32 ^ 0b0101);
    println!("1 << 5 is {}", 1u32 << 5);
    println!("0x80 >> 2 is 0x{:x}", 0x80u32 >> 2);

    // Use underscores to improve readability!
    println!("One million is written as {}", 1_000_000u32);


    //scoping and shadowing 
    let myval=12367;
    let theirval=6325;
    {
        let yourval=63276;
        println!("yourval is {}", yourval);
        let theirval=12712;
        println!(" Inside Scope => theirval is {}", theirval);
        println!("Inside Scope => myval is {}",myval);

    }

    println!("myval is {}",myval);
    println!("theirval is {}",theirval);


    //printing planck's constant 
    println!("constant is {}",PLANCK);

    //print the static value 
    println!("static value is {}",dburl);

}
