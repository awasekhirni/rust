// rust comments

// this code rustc appmain.rs
// this is the main function 

fn main(){
	println!("Welcome to RUST Programming Syed Awase Khirni!");
   


}
