#[derive(Debug)]
enum CarType{
    Hatchback,
    Sedan,
    SUV,
    MUV
}

#[derive(Debug)]
enum Color{
    Red,
    Blue,
    Green,
    Black
}

#[derive(Debug)]
struct Car{
    manufacturer:String,
    seats:u32,
    torque:u32,
    color:Color,
    cartype:CarType
}




fn main() {
    println!("Rust Programming- Structure + Enumerators- Syed Awase 2017");
    let mycolorchoice=Color::Red;
    let mycarchoice=CarType::Sedan;
    let toyota=Car{
        manufacturer:String::from("Toyoda Motor Corporation"),
        seats:5,
        torque:3000,
        color:mycolorchoice,
        cartype:mycarchoice
    };

    println!("{:?}",toyota);
    


}
