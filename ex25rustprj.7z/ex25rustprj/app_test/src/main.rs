/*
 *   Copyright (c) 2018 Syed Awase Khirni 
 *  awasekhirni@gmail.com www.sycliq.com www.territorialprescience.com  
 *   All rights reserved.
 */
extern crate app_lib;
use app_lib::afactory;

fn main() {
    println!("Ex25-Rust Design Patterns - Abstract Factory Design Pattern");
   let mac_app = afactory::Application::new_gui_factory("mac");
    let btn = mac_app.create_button();
    btn.paint();
    let cb= mac_app.create_checkbox();
    cb.paint();
   let win_app = afactory::Application::new_gui_factory("win");
    let wbtn = win_app.create_button();
    wbtn.paint();
    let wcb= win_app.create_checkbox();
    wcb.paint()


}
