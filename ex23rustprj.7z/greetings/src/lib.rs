pub mod greetings{
    pub mod english{
       pub fn hello() ->String {
            "hello".to_string()
        }

       pub fn goodbye()->String{
            "goodbye".to_string()
        }
    }


    pub mod arabic{
       pub fn marhaba()->String{
            "ahlan wa sahlan wa marhaban".to_string()
        }

       pub fn allahhafiz()->String{
            "As-Salam Walekum! Allah Hafiz!".to_string()
        }
    }
}


#[cfg(test)]
mod tests {
    #[test]
    fn it_works() {
        assert_eq!(2 + 2, 4);
    }
}
