extern crate greetings;
use greetings::greetings::english;
use greetings::greetings::arabic;

fn main() {
    println!("Rust Programming - Creating a Custom Crate - Syed Awase 2017");
    println!("{}",english::hello());
    println!("{}",english::goodbye());
    println!("{}",arabic::marhaba());
    println!("{}",arabic::allahhafiz());
}
